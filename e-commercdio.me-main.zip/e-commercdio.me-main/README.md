# e-commerce.me
Desafio: Refinando projeto de uma e-commerce 

Projeto conceitual de banco de dados - E-Commerce

Realização do projeto foi com base nos dados informados pela DIO no curso DATABASE EXPERIENCE
